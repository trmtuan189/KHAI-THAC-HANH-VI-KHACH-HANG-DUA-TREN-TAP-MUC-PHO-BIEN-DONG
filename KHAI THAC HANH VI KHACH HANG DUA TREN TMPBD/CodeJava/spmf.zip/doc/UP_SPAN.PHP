	<!doctype html>
	<html lang="en">
	  <head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>Example: Mining High-Utility Episodes in a Complex Event Sequence using the US-SPAN Algorithm  (SPMF - Java)</title>
		<link rel="stylesheet" href="docstyle.css"/>
	</head>
	  <body>
		<div width="100%" class="container">
			  <div class="content">
				<!----------START------>
<h1>Mining High-Utility Episodes in a Complex Event Sequence using the US-SPAN Algorithm (<a href="documentation.html">SPMF documentation)</a></h1>
<!-------------  (3) Change the name of the algorithm here: --------------------------------->
<p>This example explains how to run the <strong>UP-SPAN algorithm</strong> using the <a href="https://www.philippe-fournier-viger.com/spmf/">SPMF open-source data mining library</a>.</p>
<!--------------(4) Insert the example here:------------->
<h2>How to run this example?</h2>
<ul>
  <li><strong>If you are using the graphical interface, </strong>(1)
    choose the <strong>&quot;<span class="highlight">UP-SPAN</span>&quot;</strong> algorithm<strong>, </strong> (2) select the input file <strong>&quot;<span class="highlight">ExampleTUP.txt</span><span class="highlight">&quot;</span></strong>,
    (3) set the output file name (e.g. &quot;<span class="highlight">output.txt</span>&quot;)
    (4) set the minimum utility to <strong>0.56, </strong>(5) set the maximum time duration to 2, (6) set <em>outputSingleEvents = true </em>and
    (6) click &quot;<span class="highlight">Run algorithm</span>&quot;.</li>
  <li><strong>If you want to execute this example from the command line</strong>,
    then execute this command: <br>
    <span class="highlight">java -jar spmf.jar run<strong><span class="highlight"> UP-SPAN </span></strong><strong><span class="highlight">ExampleTUP</span></strong>.txt
      output.txt 0.56 2 false </span> in a folder containing <span class="highlight">spmf.jar</span> and the example input file <span class="highlight">ExampleTUP.txt</span>.</li>
  <li><strong>If you are using the source code version of SPMF, </strong>launch
    the file <strong><span class="highlight">&quot;MainTestUP_SPAN.java&quot;</span></strong> in the package <span class="highlight"><strong>ca.pfv.SPMF.tests</strong></span>. </li>
</ul>
<h2>What is UP-SPAN?</h2>
<p><strong>UP-SPAN </strong> (Wu et al., 2013) is an
    algorithm for discovering<strong> high-utility episodes </strong>in a
    complex event sequence containing utility information (which is equivalent to a transaction database orderd by time). </p>
  <p><strong>High utility episode mining </strong>can be used to discover  subsequences of events (<strong>episodes</strong>) that have a high importance (e.g. yield a high profit) in a complex event sequence. A c<strong>omplex event sequence</strong> is an ordered list of event sets, where an event sets is a set of events occuring simultaneously. In a complex event sequence with utility information, each event is annotated with some utility information (numbers indicating the importance of the event - e.g. profit yield by the event).</p>
  <p>Although high utility episode mining algorithms are often presented in the context of
    analyzing customer transaction data, there exist other applications.</p>

  <h2>What is the input?</h2>
  <p><strong>UP-SPAN</strong> takes as input a <strong>complex event sequence</strong> (also called a transaction database)
    with utility information, a minimum utility threshold <em>min_utility </em>(a percentage), a <em>minimum time duration</em> (an integer), and a optional boolean parameter <em>outputSingleEvents</em>. Let's consider the following
    sequence consisting of 5 time points (t1,t2...t6) and 7 event types (1, 2,
    3, 4, 5, 6, 7). This database is provided in the text file &quot;<strong>ExampleTUP.txt</strong>&quot;
    in the package <strong>ca.pfv.spmf.tests </strong>of the SPMF
    distribution<strong>.</strong></p>
  <table align="center" border="1" width="721">
    <tbody>
      <tr>
        <td width="56"><strong>Time points</strong> <br></td>
        <td width="156"><strong>Events</strong></td>
        <td width="190"><strong>Total event utility </strong></td>
        <td width="291"><strong>Utilities of each event </strong></td>
      </tr>
      <tr>
        <td><strong>t1</strong></td>
        <td>5 3 </td>
        <td>14</td>
        <td>10 4 </td>
      </tr>
      <tr>
        <td><strong>t2</strong></td>
        <td>3</td>
        <td>10</td>
        <td>10</td>
      </tr>
      <tr>
        <td><strong>t3</strong></td>
        <td>5 4 </td>
        <td>13</td>
        <td>10 3 </td>
      </tr>
      <tr>
        <td><strong>t4</strong></td>
        <td>2</td>
        <td>4</td>
        <td>4</td>
      </tr>
      <tr>
        <td><strong>t5</strong></td>
        <td>4 1 </td>
        <td>3</td>
        <td>1 2 </td>
      </tr>
      <tr>
        <td><strong>t6</strong></td>
        <td>7 6 </td>
        <td>5</td>
        <td>2 3 </td>
      </tr>
    </tbody>
  </table>
  
    <p>Each line of the<strong> sequence </strong>is called an<strong> event set </strong>and consists of:</p>
    <ul>
      <li>a time point (first column)</li>
      <li>a set of events that are considered simultaneous at this time point (the second column of the table), </li>
      <li>the sum of the utilities (e.g. profit) of the events (the third column of the table),</li>
      <li>the utility (importance) of each event at this time point (the fourth column of the
        table).</li>
    </ul>
    <p>Note that the value in the third column of each line is the
      sum of the values in the fourth column.</p>
    <p>What are real-life examples of such a database? There are
      several applications in real life. One application is a sequence of customer
      transactions. Imagine that each time points is a set of items purchased by a customer at a given time. In that case, a time point is a transaction and events are items purchased by thecustomer. Then, the utilities of events are the profit generated by the sale of each item (event) in each transaction (time point). In that example, the first transaction (time point) named &quot;<strong>t1</strong>&quot;
      represents that a customer bought items 5 and 3. The amount of money (utility) spent for each
      item is respectively 10$ and 4 $. The total amount
      of money spent in this transaction is 10 + 4 = 14 $.</p>
  

    <h2>What is the output?</h2>
    <p><em> </em>The output of<strong> UP-SPAN </strong>is the set of <strong>high utility episodes </strong> having a utility no less than
    a <em><strong>min_utility</strong></em> threshold (a positive integer)
    set by the user. To explain what is a high utility episodes, it is
    necessary to review some definitions. </p>
  <p>An <strong>episode </strong> is a subsequence of the input sequence. An occurrence of an episode in a sequence is a set of no more than <em>maxTimeDuration+1 </em>consecutive events that contains the episode . The <strong>utility of an episode</strong> is the sum the utilities of its minimal occurrences in the sequence (for a more formal definition, see the paper by Wu et al., 2013). </p>
  <p><strong>For example, consider the episode &lt;(3), (4,5), (2)&gt;</strong> which represents that event 3 was followed by events 4 and 5 at the same time, and then followed by event 2. If <em>maxTimeDuration</em> = 2, and occurrence of this episode is the time points t2, t3, t4. The utility of this episode is the sum of the utility of &lt;(3), (4,5), (2)&gt; at the time points t2, t3, t4, that is 10 + 10 + 3 + 16 = 39.</p>
  <p>The<strong> total utility of the input sequence</strong> <em>total_utility </em>is the sum of the third column in the previous example, that is: 14 + 10 + 13 + 16 + 3 + 5 = 61. </p>
  <p>A<strong> high utility episode </strong> is an episode such that its utility is no
    less than <em>min_utility</em> * <em>total_utility</em>. For a given input sequence, the <strong>UP-SPAN </strong>algorithm outputs all high utility episodes. For example, consider that <em>min_utility = 0.56.</em> If we run <strong>UP-SPAN </strong>with <em>min_utility =</em> <strong>0.56</strong>, <em>maxTimeDuration = 2, </em>we obtain 3 <strong>high-utility
    episodes that have a utility no less than </strong>0.56 * 61 = 34.16. </p>

<table align="center" border="1" width="226">
  <tbody>
    <tr>
      <td width="113"><strong> high utility episode </strong></td>
      <td width="97"><strong>utility</strong></td>
    </tr>
    <tr>
      <td>(3, 5)(3)(4, 5) </td>
      <td>37</td>
    </tr>
    <tr>
      <td>(3)(4,5)(2)</td>
      <td>39</td>
    </tr>
    <tr>
      <td>(3)(5)(2)</td>
      <td>37</td>
    </tr>
  </tbody>
</table>

  <p>If the input sequence is a sequence of transactions made by a customer in a store, we could
    interpret these results as all the subsequences of purchases made by a customer that
    generated a profit of 34.16 $ or more. </p>
  <p>Note that by the definition of the problem of high utility episode mining, episodes containing only 1 item are not output. To include these episodes in the results, set the parameter <em>outputSingleEpisodes</em> to <em>true.</em></p>

  <h2>Input file format</h2>
  <p>The <strong> input file format</strong> of <strong>UP-SPAN </strong>is
    defined as follows. It is a text file. Each lines represents an event set. Each line is composed of three sections, as follows.</p>
  <ul>
    <li>First, the events (items) contained in the event set are listed. An
      event is represented by a positive integer. Each item is separated from
      the next item by a single space. It is assumed that all events within a
      same event set (line) are sorted according to a total order (e.g.
      ascending order) and that no event can appear twice within the same
      event set.</li>
    <li>Second, the symbol &quot;:&quot; appears and is followed by the
      total utility of the event set (an integer).</li>
    <li>Third, the symbol &quot;:&quot; appears and is followed by the utility of
      each event in this event set (an integer), separated by single spaces.</li>
  </ul>
  <p>For example, for the previous example, the input file is defined
    as follows:</p>
  
    <p>@FILETYPE=&quot;Transaction database with utility values&quot;<br>
      @SOURCE=&quot;SPMF SOFTWARE https://philippe-fournier-viger.com/spmf/&quot;<br>
      5 3:14:10 4<br>
      3:10:10<br>
      5 4:13:10 3<br>
      2:16:16<br>
      4 1:3:1 2<br>
      7 6:5:2 3</p>
  
  <p>The first two lines are optional metadata. The first line indicate the type of file and the second line describes the source of the data. Then it is the data section.<br>
    Consider the first line of data. It means that at the first time point, two events named 5 and 3 occurred, and that these events respectively have a utility of 10 and 4. The total utility of this event set is thus 10 + 4 = 14.  The following lines follow the same format.</p>

  <h2>Output file format</h2>
  <p>The <strong>output file format</strong> is defined as follows. It
    is a text file. The first two lines are metadata indicating the type of patterns in this file and the source of the data. Then the following lines provide the list of patterns. Each line is a high utility episode. Each event 
    in a high utility episode is a positive integer and items from the same
    event set within an episode are separated by single spaces. The value
    &quot;-1&quot; indicates the end of an event set. On each line, the episode is first indicated. Then, the keyword &quot;#UTIL:&quot; appears followed
    by an integer indicating the utility of the pattern (a positive integer). For example, a few lines from the output file from the
  previous example are shown below:</p>
  
    <p>@FILETYPE=&quot;High-Utility episodes&quot;<br>
@SOURCE=&quot;SPMF SOFTWARE https://philippe-fournier-viger.com/spmf/&quot;<br>
3 5 -1 3 -1 4 5 -1 #UTIL: 37<br>
      3 -1 4 5 -1 2 -1 #UTIL: 39<br>
    3 -1 5 -1 2 -1 #UTIL: 36</p>
  
  <p>The first line indicates that the high utility episode consisting of the event set (3, 5), followed by the itemset (3), followed by (4, 5) has a
    utility of 37.</p>

  <h2>Performance</h2>
  <p><strong>High utility episode mining</strong> is a more difficult
    problem than the traditional problem of frequent episode mining, as the former is more general.. <strong>UP-SPAN </strong>is the first algorithm for high utility episode mining. Recently, some faster algorithms like <a href="HUE_SPAN.pdf">HUE-SPAN</a> have been proposed (also offered in SPMF). </p>
  <p><span class="highlight"><strong>Important note</strong>:</span> <span class="highlight">If you are interested to compare the episodes found by <strong>UP-SPAN </strong> with those found by <strong>HUE-SPAN (</strong>Fournier-Viger et al., 2019)  , it should be noted that the definition of window is slightly different for these two algorithms. </span>The difference is that maxWindow must be increased by 1 for HUE-Span to obtain the same result as UP-Span. Thus in the above example, if maxWindow = 2 for HUE-SPAN, then UP-SPAN must be run with maxWindow =1 to obtain the same result. Besides, it is also important to note that HUE-SPAN let the user use a novel definition of utility (as presented in the HUE-SPAN paper). To obtain the same results as UP-SPAN using HUE-SPAN it is necessary to use the old definition of utility. This is achieved by setting UseTraditionalUtility = true in the graphical user interface of SPMF or by setting CheckMaximumUtility = false in the source code of SPMF. Then the two algorithms should return the same result.</p>
  <p>Besides other algorithms for variations of the high utility episodes mining are offered in SPMF such as the <strong>TUP </strong>algorithm for top-k high utility episode mining. </p>

  <h2>Implementation details</h2>
  <p>This is the original implementation of  UP-SPAN obtained from UP-Miner under the GPL license. </p>

  <h2>Where can I get more information about the UP-SPAN algorithm?</h2>
  <p>This is the reference of the article describing the UP-SPAN
    algorithm:</p>
  <p>Wu, Cheng-Wei, et al. &quot;Mining high utility episodes in complex event sequences.&quot; <em>Proceedings of the 19th ACM SIGKDD international conference on Knowledge discovery and data mining</em>. ACM, 2013.</p>
				<!----------END------>
				<div class="footer">
				  <p><a href="documentation.html">&lt;&lt; Return to table of contents of SPMF documentation</a></p>
				  <p>Copyright &copy; 2008-2026 <a href="https://www.philippe-fournier-viger.com">Philippe Fournier-Viger</a>. All rights reserved.</p>
				</div>
		  </div>
	  </div>
		</table>
	  </body>
	</html>
